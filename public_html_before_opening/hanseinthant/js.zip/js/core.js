$(document).ready(function(){

    $("#datepicker1").datepicker();
    $("#datepicker2").datepicker();

    $('#timepicker').timepicker();
    //$('input.timepicker').timepicker({ timeFormat: 'h:mm:ss p' });

    

   
});
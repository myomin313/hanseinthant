<?php
include_once('../config.php');
if($_SERVER["REQUEST_METHOD"] == "POST")
{

$id=$_POST['id']; 
$code=$_POST['code'];
$brandname=$_POST['brandname'];
$commodity=$_POST['commodity'];  
$LUser=$_POST['LUser']; 
$UpdateTime= date("Y-m-d H:i:s"); 

       
        $sql="UPDATE code SET code='$code',brandname='$brandname',commodity='$commodity', updated_at='$UpdateTime',  updated_by='$LUser' WHERE id='$id'";
        mysqli_query($con ,$sql);
        echo"<script>alert('Successfully Updated');</script>";
        echo "<script type='text/javascript'>window.top.location='detail.php?id=$id';</script>";exit;
     


}
?>
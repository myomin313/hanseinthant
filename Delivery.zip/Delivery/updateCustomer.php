<?php
     // start myo min 
      include_once('../config.php');      
        $oldCustomer=$_POST['oldCustomer'];
        $oldDO_No=$_POST['oldDO_No'];
        $oldBranch=$_POST['oldBranch'];
        $okyaku=$_POST['okyaku'];
        //$Job_No = $_POST['JOB_No'];
        $Location=$_POST['Location']; 
        $DO_No=$_POST['DO_No'].''.$_POST['dep_name'];
        $Delivery_date=$_POST['Delivery_date']; 
        $LUser=$_POST['LUser'];
        
      
         foreach($_POST['Commodity'] as $row =>$Commodity) { 
           $Commoditys = mysqli_real_escape_string($con,$_POST['Commodity'][$row]);
           $BrandName  = mysqli_real_escape_string($con,$_POST['BrandName'][$row]);
           $code  = mysqli_real_escape_string($con,$_POST['code'][$row]);
           // 11.13.2019 myo min start
             $sqls = "SELECT * FROM job where Customer= '$oldCustomer' and Location= '$oldBranch' and BrandName = '$BrandName' and Commodity = '$Commoditys'";              
                  $result= mysqli_query($con,$sqls);      
                  $row = $result->fetch_assoc();                    
                  $OCustomer = mysqli_real_escape_string($con,$row['Customer']);
                  $OBrandName = mysqli_real_escape_string($con,$row['BrandName']);
                  $OCommodity = mysqli_real_escape_string($con,$row['Commodity']);
                  $Ocode = mysqli_real_escape_string($con,$row['code']);
                  $ORemarks_Item = mysqli_real_escape_string($con,$row['Remarks_Item']);
                  $Oid=$row['id'];                 
                  $OJob_date= $row['Job_date'];
                  $OJob_No= $row['Job_No'];
                  $OProject= $row['Project'];
                  $OWIP= $row['WIP'];                 
                  $OPL= $row['PL'];
                  $OType= $row['Type'];
                  $OLocation= $row['Location'];    
                  $ObalanceWIP= $row['balanceWIP'];
                  $ObalanceJOB= $row['balanceJOB'];
                  $RecordTime= date("Y-m-d H:i:s"); 
                  $status ='Update';                 
                  $sqli="INSERT INTO job_history(input_ID,Customer,OCustomer,BrandName,OBrandName,Commodity,OCommodity,code,Ocode,Remarks_Item,ORemarks_Item,Job_date,OJob_date,Job_No,OJob_No,Project,OProject,WIP,OWIP,Type,OType,Location,OLocation,PL,OPL,RecordTime,Recoder,status)
                 VALUES ('$Oid','$okyaku','$OCustomer','$OBrandName','$OBrandName','$OCommodity','$OCommodity','$Ocode','$Ocode','$ORemarks_Item','$ORemarks_Item','$OJob_date','$OJob_date','$OJob_No','$OJob_No','$OProject','$OProject','$OWIP','$OWIP','$OType','$OType','$Location','$oldBranch','$OPL','$OPL','$RecordTime','$LUser','$status')";
                  mysqli_query($con ,$sqli);

                  $sqls = "SELECT * FROM delivery where Customer= '$oldCustomer' and Location= '$oldBranch' and BrandName = '$BrandName' and code = '$code' and Commodity = '$Commoditys'";
                   $results=mysqli_query($con ,$sqls); 
                  $row = $results->fetch_assoc();
                  $OCustomer = mysqli_real_escape_string($con,$row['Customer']);
                  $OBrandName = mysqli_real_escape_string($con,$row['BrandName']);
                  $OCommodity = mysqli_real_escape_string($con,$row['Commodity']);
                  $Ocode = mysqli_real_escape_string($con,$row['code']);
                  $ORemark_Item = mysqli_real_escape_string($con,$row['Remark_item']);
                  $Oid=$row['id'];   
                  $ODelivery_date= $row['Delivery_date'];
                  $ODO_No= $row['DO_No'];
                  $OJOB_No= $row['JOB_No'];
                  $OQty= $row['Qty'];
                  $OPL= $row['PL'];
                  $OType= $row['Type'];
                  $OLocation= $row['Location']; 
                $sqldi="INSERT INTO delivery_history(input_ID,Customer,OCustomer,BrandName,OBrandName,Commodity,OCommodity,code,Ocode,Remark_Item,ORemark_Item,ODelivery_date,ODelivery_date,DO_No,ODO_No,JOB_No,OJOB_No,OQty,OQty,PL,OPL,Type,OType,Location,OLocation,RecordTime,Recorder,status)
                VALUES ('$Oid','$okyaku','$OCustomer','$OBrandName','$OBrandName','$OCommodity','$OCommodity','$Ocode','$Ocode','$ORemark_Item','$ORemark_Item','$ODelivery_date','$ODelivery_date','$DO_No','$ODO_No','$OJOB_No','$OJOB_No','$OQty','$OQty','$OPL','$OPL','$OType','$OType','$Location','$OLocation','$RecordTime','$LUser','$status')";
                mysqli_query($con ,$sqldi);

                $sql="SELECT * FROM returns WHERE Customer = '$oldCustomer' and department = '$oldBranch' and BrandName = '$BrandName' and Commodity = '$Commoditys' and code='$code' ";
                  $results=mysqli_query($con ,$sql); 
                  $row = $results->fetch_assoc();
                  $OCustomer = mysqli_real_escape_string($con,$row['Customer']);
                  $OBrandName = mysqli_real_escape_string($con,$row['BrandName']);
                  $OCommodity = mysqli_real_escape_string($con,$row['Commodity']);
                  $Ocode = mysqli_real_escape_string($con,$row['code']);
                  $ORemarks_item = mysqli_real_escape_string($con,$row['Remarks_item']);
                  $Oid=$row['id'];
                  $OReturn_date= $row['Return_date'];
                  $OReturn_no= $row['Return_no'];
                  $ODO_No= $row['DO_No'];
                  $OPL= $row['PL'];                                  
                  $Odepartment= $row['department'];
                  $OQty= $row['Qty'];
                  $OType= $row['Type']; 
                                            
                $sqlir="INSERT INTO customerreturn_history(input_ID,Customer,OCustomer,BrandName,OBrandName,Commodity,OCommodity,code,Ocode,Remarks_item,ORemarks_item,Return_date,OReturn_date,Return_no,OReturn_no,DO_No,ODO_No,PL,OPL,department,Odepartment,Qty,OQty,Type,OType,RecordTime,Recorder,status) 
                VALUES ('$Oid','$okyaku','$OCustomer','$OBrandName','$OBrandName','$OCommodity','$OCommodity','$Ocode','$Ocode','$ORemarks_item','$ORemarks_item','$OReturn_date','$OReturn_date','$OReturn_no','$OReturn_no','$ODO_No','$ODO_No','$OPL','$OPL','$Location','$Odepartment','$OQty','$OQty','$OType','$OType','$RecordTime','$LUser','$status')";
                  mysqli_query($con ,$sqlir);


           $sqlq = "UPDATE delivery SET Delivery_date ='$Delivery_date',Customer ='$okyaku',Location ='$Location',DO_No='$DO_No' WHERE  Customer = '$oldCustomer' and DO_No = '$oldDO_No'";
                   mysqli_query($con ,$sqlq);
           // 11.13.2019 myo min end           
            $sqld = " UPDATE job SET Customer ='$okyaku',Location ='$Location' WHERE Customer = '$oldCustomer' and Location = '$oldBranch' and BrandName = '$BrandName' and Commodity = '$Commoditys' and code='$code'";
             mysqli_query($con ,$sqld);

           $sqlr = " UPDATE returns SET Customer ='$okyaku',department ='$Location',DO_No='$DO_No' WHERE Customer = '$oldCustomer' and department = '$oldBranch' and BrandName = '$BrandName' and Commodity = '$Commoditys' and code='$code'";
              mysqli_query($con ,$sqlr);
               echo"<script>alert('Successfully Updated');</script>";
echo "<script type='text/javascript'>window.top.location='list.php?namelist=&year=&month=&day=';</script>";
         }
        //end myo min 

?>